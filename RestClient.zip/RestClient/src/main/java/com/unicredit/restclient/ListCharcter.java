package com.unicredit.restclient;

import java.util.ArrayList;
import java.util.List;

public class ListCharcter {

    private Info info;

    private List<Character> results;

    public ListCharcter(Info info) {

        this.info = info;
        this.results = new ArrayList<>();

    }

     public  Info getInfo(){

        return  this.info;
     }
    public List<Character> getResults() {
        return results;
    }


}