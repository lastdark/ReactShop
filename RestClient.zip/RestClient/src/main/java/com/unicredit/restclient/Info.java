package com.unicredit.restclient;

public class Info {

    private Integer count;
    private String pages;
    private  String  next;
    private String  prev;

    public Info(Integer count, String pages, String next, String prev) {
        this.count = count;
        this.pages = pages;
        this.next = next;
        this.prev = prev;
    }

    @Override
    public String toString() {
        return "Info{" +
                "count=" + count +
                ", pages='" + pages + '\'' +
                ", next='" + next + '\'' +
                ", prev='" + prev + '\'' +
                '}';
    }
}
