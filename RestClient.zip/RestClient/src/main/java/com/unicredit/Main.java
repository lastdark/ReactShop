package com.unicredit;

import com.google.gson.Gson;
import com.unicredit.httpclient.HttpRestClient;
import com.unicredit.restclient.ListCharcter;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import sun.net.www.http.HttpClient;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) throws URISyntaxException, IOException {

       String url="https://rickandmortyapi.com/api/character?";
        HttpRestClient httpRestClient=new HttpRestClient();
        Map<String,String> parm=new HashMap<>();
        parm.put("page","2");

        HttpGet httpGet= (HttpGet) httpRestClient.getMethod(url,parm,null);

        CloseableHttpClient httpclient = HttpClients.createDefault();
        HttpResponse httpresponse = httpclient.execute(httpGet);
        HttpEntity entity = httpresponse .getEntity();


        String res1= EntityUtils.toString(entity);
       // System.out.println(res1);

        Gson gson = new Gson();

         ListCharcter listCharcter = gson.fromJson(res1,ListCharcter.class);
         System.out.println(listCharcter.getInfo());
         listCharcter.getResults().forEach((temp)->{


               System.out.println(temp);
         });

    }
}