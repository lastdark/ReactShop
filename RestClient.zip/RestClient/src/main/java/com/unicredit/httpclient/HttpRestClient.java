package com.unicredit.httpclient;


import com.unicredit.httpclient.interfacerest.RestClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.client.utils.URIBuilder;

import java.net.URISyntaxException;
import java.util.Map;

public class HttpRestClient implements RestClient {



    @Override
    public Object getMethod(String url, Map queryParm, Object Header) throws URISyntaxException {

        HttpGet httpget = new HttpGet( url);
        URIBuilder uri = new URIBuilder(httpget.getURI());
        for (Object paramKey : queryParm.keySet()) {
            uri.addParameter((String)paramKey, (String)queryParm.get(paramKey));
        }

        ((HttpRequestBase) httpget).setURI(uri.build());

        return  httpget;

    }

    @Override
    public Object postMethod(String url, Object parmBody, Object Header) {
        return null;
    }

    @Override
    public Object deleteMethod(String url, Map queryParm, Object Header) {
        return null;
    }

    @Override
    public Object putMethod(String url, Map queryParm, Object dataBody, Object Header) {
        return null;
    }
}
