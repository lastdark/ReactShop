package com.unicredit.httpclient.interfacerest;

import java.net.URISyntaxException;
import java.util.Map;

public interface RestClient<T> {

    public  T getMethod(String url , Map<String,String> queryParm, T Header) throws URISyntaxException;
    public T postMethod(String url ,T parmBody,T Header);
    public T putMethod(String url , Map<?,?> queryParm ,T dataBody,T Header);
    public T deleteMethod(String url, Map<?,?> queryParm,  T Header);

}
